## v2.3.2

* Added support for PHP 5.y.z. Thanks to [por](//github.com/por).

## v2.3.1

* Only parse HTTP response headers if the `CURLOPT_HEADER` option is present. Thanks to [hmanprod](//github.com/hmanprod).
