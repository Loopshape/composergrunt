<!--
    
    GRUNT + COMPOSER SKELETON
    
    Assembled by Arjuna Noorsanto
    webmaster@loopshape.com
    
    http://loopshape.com/
    
-->
<?php

namespace Skeleton\Start;

require_once "./../vendor/autoload.php";

// Please install first all package dependencies!!!

// ****************************
// ...here comes your code...
// ****************************
